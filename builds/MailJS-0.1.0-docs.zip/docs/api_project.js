define({
  "name": "MailJS",
  "version": "0.1.0",
  "description": "",
  "title": "MailJS RESTfull api documentation",
  "url": "https://mail.atlasdev.nl/api/v1",
  "withCompare": "true",
  "sampleUrl": false,
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2015-12-06T22:37:05.964Z",
    "url": "http://apidocjs.com",
    "version": "0.13.1"
  }
});